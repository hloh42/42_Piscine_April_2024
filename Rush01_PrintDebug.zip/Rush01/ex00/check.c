/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: prtan <prtan@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/14 14:36:06 by prtan             #+#    #+#             */
/*   Updated: 2024/04/14 14:36:13 by prtan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	check_row_left(int row[4], int bound)
{
	int	max_height;
	int	count;
	int	i;

	max_height = 0;
	count = 0;
	i = 0;
	while (i < 4)
	{
		if (row[i] > max_height)
		{
			max_height = row[i];
			count++;
		}
		i++;
	}
	if (count == bound)
	{
		return (1);
	}
	else
	{
		return (0);
	}
}

int	check_row_right(int row[4], int bound)
{
	int	max_height;
	int	count;
	int	i;

	max_height = 0;
	count = 0;
	i = 3;
	while (i >= 0)
	{
		if (row[i] > max_height)
		{
			max_height = row[i];
			count++;
		}
		i--;
	}
	if (count == bound)
	{
		return (1);
	}
	else
	{
		return (0);
	}
}

int	check_col_up(int grid[4][4], int j, int bound)
{
	int	max_height;
	int	count;
	int	i;

	max_height = 0;
	count = 0;
	i = 0;
	while (i < 4)
	{
		if (grid[i][j] > max_height)
		{
			max_height = grid[i][j];
			count++;
		}
		i++;
	}
	if (count == bound)
	{
		return (1);
	}
	else
	{
		return (0);
	}
}

int	check_col_down(int grid[4][4], int j, int bound)
{
	int	max_height;
	int	count;
	int	i;

	max_height = 0;
	count = 0;
	i = 3;
	while (i >= 0)
	{
		if (grid[i][j] > max_height)
		{
			max_height = grid[i][j];
			count++;
		}
		i--;
	}
	if (count == bound)
	{
		return (1);
	}
	else
	{
		return (0);
	}
}

int	check_bound(int grid[4][4], int bounds[16])
{
	int	i;
	int	j;	

	i = 0;
	while (i < 4)
	{
		if (!check_row_left(grid[i], bounds[i])
			|| !check_row_right(grid[i], bounds[i + 4]))
			return (0);
		i++;
	}
	j = 0;
	while (j < 4)
	{
		if (!check_col_up(grid, j, bounds[j + 8])
			|| !check_col_down(grid, j, bounds[j + 12]))
			return (0);
		j++;
	}
	return (1);
}
