/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   valid_solve.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: prtan <prtan@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/14 14:54:04 by prtan             #+#    #+#             */
/*   Updated: 2024/04/15 22:49:08 by hloh             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
int count = 0;
void	print_grid(int grid[4][4]);
//check.c
int	check_bound(int grid[4][4], int bounds[16]);

int	is_valid(int grid[4][4], int row, int col, int num)
{
	int	i;

	i = 0;
	while (i < 4)
	{
		if (grid[row][i] == num || grid[i][col] == num)
			return (0);
		i++;
	}
	return (1);
}

int	solve(int grid[4][4], int bounds[16], int position)
{
	int	i;
	int	j;
	int	value;

	i = position / 4;
	j = position % 4;
	value = 1;
	if (position == 16)
		return (check_bound(grid, bounds));
	while (value <= 4)
	{
		if (is_valid(grid, i, j, value))
		{
			grid[i][j] = value;
			if (solve(grid, bounds, position + 1))
			{
				count++;
				return (1);
			}
		}
		value++;
	}
	printf("Cycle : %d\n", count);
	print_grid(grid);
	printf("\n");
	//printf("value : %d , grid[%d][%d]" , value , i , j );
	grid[i][j] = 0;
	return (0);
}
