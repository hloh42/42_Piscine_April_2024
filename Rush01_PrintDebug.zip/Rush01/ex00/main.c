/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: prtan <prtan@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/14 15:06:31 by prtan             #+#    #+#             */
/*   Updated: 2024/04/14 22:19:32 by hloh             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

void	print_grid(int grid[4][4]);
void	handle1(int grid[4][4], int bounds[16]);
void	handle4(int grid[4][4], int bounds[16]);
int		solve(int grid[4][4], int bounds[16], int position);

int	input_handling(int argc, char **argv, int bounds[16])
{
	int	index;
	int	bound_index;

	index = 0;
	bound_index = 0;
	if (argc != 2)
	{
		write(1, "Error\n", 6);
		return (1);
	}
	while (argv[1][index] != '\0' && bound_index < 16)
	{
		if (argv[1][index] >= '1' && argv[1][index] <= '4')
		{
			bounds[bound_index] = argv[1][index] - '0';
			bound_index++;
		}
		index += 2;
	}
	if (bound_index != 16)
	{
		write(1, "Error\n", 6);
		return (1);
	}
	return (0);
}

void	init_skyscrapper(int grid[4][4])
{
	int	i;
	int	j;

	i = 0;
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			grid[i][j] = 0;
			j++;
		}
		i++;
	}
}

int	main(int argc, char **argv)
{
	int	grid[4][4];
	int	bounds[16];

	if (input_handling(argc, argv, bounds))
	{
		return (1);
	}
	init_skyscrapper(grid);
	if (solve(grid, bounds, 0))
	{
		print_grid(grid);
	}
	else
	{
		write(1, "Error\n", 6);
	}
	return (0);
}
